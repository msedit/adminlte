<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Masters extends Controller
{
    public function show()
    {

    	return view('layouts.master');

    }
}
